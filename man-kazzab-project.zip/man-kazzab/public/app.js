let ws=null, me=null, room=null, role=null;
const $=id=>document.getElementById(id);
function connect(){
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}`);
  ws.onmessage=e=>{const d=JSON.parse(e.data); if(d.type==="joined"){me=d.playerId;$("roomCode").textContent=d.code;$("home").classList.add("hidden");$("room").classList.remove("hidden")} if(d.type==="state"){room=d.state;role=d.role;render()} if(d.type==="error")$("msg").textContent=d.message};
  ws.onclose=()=>setTimeout(connect,1500);
}
function send(o){if(ws&&ws.readyState===1)ws.send(JSON.stringify(o))}
function name(){return $("name").value.trim()||"لاعب"}
function createRoom(){send({action:"create",name:name()})}
function joinRoom(){send({action:"join",name:name(),code:$("code").value.trim().toUpperCase()})}
function startGame(){send({action:"start"})}
function render(){
 $("players").innerHTML=room.players.map(p=>`<div class="player"><span>${p.avatar} ${esc(p.name)}</span><span>${p.ready?"جاهز":"غير جاهز"}</span></div>`).join("");
 if(room.phase==="lobby"){ $("room").classList.remove("hidden");$("game").classList.add("hidden"); return}
 $("room").classList.add("hidden");$("game").classList.remove("hidden");
 $("time").textContent=room.time;$("tasks").textContent=`${room.tasks.length}/4`;
 $("role").textContent=role==="liar"?"أنت الكذّاب 😈":"أنت من الطاقم 🕵️";
 let a="";
 if(room.phase==="play"){
   if(role==="crew") for(let i=0;i<4;i++) a+=`<button class="task" onclick="task(${i})">مهمة ${i+1}</button>`;
   if(role==="liar") a+=`<button class="danger" onclick="sabotage()">تخريب (-10 ثواني)</button>`;
   a+=`<button class="alt" onclick="finishVote()">بدء التصويت</button>`;
 }
 if(room.phase==="vote"){
   a="<h3>صوّت على الكذّاب</h3>"+room.players.map(p=>`<button class="voteBtn" onclick="vote('${p.id}')">${esc(p.name)}</button>`).join("");
 }
 if(room.phase==="result") a=`<h2>${room.winner==="crew"?"فاز الطاقم 🎉":"فاز الكذّاب 😈"}</h2><button onclick="restart()">جولة جديدة</button>`;
 $("actions").innerHTML=a;
}
function task(i){send({action:"task",task:i})} function sabotage(){send({action:"sabotage"})}
function finishVote(){send({action:"finishVote"})} function vote(id){send({action:"vote",target:id})} function restart(){send({action:"restart"})}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
connect();