const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 8080;
const PUBLIC = path.join(__dirname, "..", "public");
const rooms = new Map();

function id(){ return Math.random().toString(36).slice(2,8).toUpperCase(); }
function safeName(n){ return String(n||"لاعب").trim().slice(0,18) || "لاعب"; }

function roomState(r){
  return {
    code:r.code, phase:r.phase, time:r.time, host:r.host,
    players:[...r.players.values()].map(p=>({id:p.id,name:p.name,avatar:p.avatar,ready:p.ready,connected:!!p.ws})),
    tasks:r.tasks, sabotages:r.sabotages, winner:r.winner
  };
}
function send(ws,obj){ if(ws && ws.readyState===1) ws.send(JSON.stringify(obj)); }
function broadcast(r){
  const s=roomState(r);
  for(const p of r.players.values())
    send(p.ws,{type:"state",state:s,role:(r.phase==="play"||r.phase==="vote"||r.phase==="result")?p.role:null});
}
function newRoom(){
  const code=id();
  const r={code,phase:"lobby",host:null,players:new Map(),liarId:null,time:120,timer:null,tasks:[],sabotages:0,winner:null,votes:new Map()};
  rooms.set(code,r); return r;
}
function start(r){
  if(r.players.size<4) return false;
  const arr=[...r.players.values()];
  r.liarId=arr[Math.floor(Math.random()*arr.length)].id;
  arr.forEach(p=>p.role=p.id===r.liarId?"liar":"crew");
  r.phase="play"; r.time=120; r.tasks=[]; r.sabotages=0; r.votes.clear(); r.winner=null;
  clearInterval(r.timer);
  r.timer=setInterval(()=>{r.time--; if(r.time<=0){r.phase="vote";clearInterval(r.timer)} broadcast(r)},1000);
  broadcast(r); return true;
}
function finish(r){
  clearInterval(r.timer); r.timer=null;
  const counts={};
  for(const v of r.votes.values()) counts[v]=(counts[v]||0)+1;
  let picked=null,best=0;
  for(const [pid,c] of Object.entries(counts)){if(c>best){best=c;picked=pid}}
  r.winner=(r.tasks.length>=4 || picked===r.liarId)?"crew":"liar";
  r.phase="result"; broadcast(r);
}
function handle(ws,msg){
  let data; try{data=JSON.parse(msg)}catch{return}
  if(data.action==="create"){
    const r=newRoom(), p={id:id(),name:safeName(data.name),avatar:data.avatar||"🧑🏻",ws,ready:true,role:null};
    r.host=p.id;r.players.set(p.id,p);ws.playerId=p.id;ws.room=r;
    send(ws,{type:"joined",code:r.code,playerId:p.id});broadcast(r);return;
  }
  if(data.action==="join"){
    const r=rooms.get(String(data.code||"").toUpperCase());
    if(!r)return send(ws,{type:"error",message:"الغرفة غير موجودة"});
    if(r.phase!=="lobby")return send(ws,{type:"error",message:"الجولة بدأت بالفعل"});
    if(r.players.size>=8)return send(ws,{type:"error",message:"الغرفة ممتلئة"});
    const p={id:id(),name:safeName(data.name),avatar:data.avatar||"🧑🏻",ws,ready:true,role:null};
    r.players.set(p.id,p);ws.playerId=p.id;ws.room=r;
    send(ws,{type:"joined",code:r.code,playerId:p.id});broadcast(r);return;
  }
  const r=ws.room,p=r&&r.players.get(ws.playerId); if(!r||!p)return;
  if(data.action==="ready"){p.ready=!p.ready;broadcast(r)}
  else if(data.action==="start"){
    if(p.id!==r.host)return send(ws,{type:"error",message:"المضيف فقط يبدأ"});
    if(!start(r))send(ws,{type:"error",message:"تحتاج 4 لاعبين على الأقل"});
  }
  else if(data.action==="task" && p.role==="crew" && r.phase==="play"){
    const n=Number(data.task);
    if(Number.isInteger(n)&&n>=0&&n<4&&!r.tasks.includes(n))r.tasks.push(n);
    if(r.tasks.length>=4){r.phase="result";r.winner="crew";clearInterval(r.timer)}
    broadcast(r);
  }
  else if(data.action==="sabotage" && p.role==="liar" && r.phase==="play"){
    r.sabotages++;r.time=Math.max(5,r.time-10);broadcast(r)
  }
  else if(data.action==="finishVote" && r.phase==="play"){r.phase="vote";broadcast(r)}
  else if(data.action==="vote" && r.phase==="vote"){
    r.votes.set(p.id,String(data.target));
    if(r.votes.size>=r.players.size)finish(r); else broadcast(r);
  }
  else if(data.action==="restart" && p.id===r.host){
    r.phase="lobby";r.players.forEach(x=>x.role=null);broadcast(r)
  }
}
const server=http.createServer((req,res)=>{
  let u=req.url.split("?")[0]; if(u==="/")u="/index.html";
  const file=path.normalize(path.join(PUBLIC,u));
  if(!file.startsWith(PUBLIC))return res.writeHead(403).end();
  fs.readFile(file,(e,b)=>{
    if(e)return res.writeHead(404).end("Not found");
    const ext=path.extname(file);
    const ct={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css"}[ext]||"application/octet-stream";
    res.writeHead(200,{"Content-Type":ct});res.end(b);
  });
});
const wss=new WebSocketServer({server});
wss.on("connection",ws=>{
  ws.on("message",m=>handle(ws,m.toString()));
  ws.on("close",()=>{
    const r=ws.room;if(!r)return;
    const p=r.players.get(ws.playerId);if(p)r.players.delete(ws.playerId);
    if(r.host===ws.playerId){const n=r.players.keys().next().value;r.host=n||null}
    if(r.players.size===0){clearInterval(r.timer);rooms.delete(r.code)}else broadcast(r)
  })
});
server.listen(PORT,()=>console.log(`من الكذّاب server listening on ${PORT}`));
