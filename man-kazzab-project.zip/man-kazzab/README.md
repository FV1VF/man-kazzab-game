# من الكذّاب؟ — مشروع اللعبة

## تشغيل السيرفر
```bash
npm install
npm start
```

افتح المتصفح على `http://localhost:8080`.

## تجهيز Android APK
على كمبيوتر مثبت عليه Node.js وAndroid Studio:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
ثم من Android Studio:
Build → Build APK(s)

> اللعب بين أجهزة مختلفة يحتاج نشر خادم WebSocket على الإنترنت وتعديل عنوان الاتصال في `public/app.js` ليشير إلى خادم WSS المنشور.
